<?php
/*
Plugin Name: Social media Icons by Suhail
Plugin URI: https://www.suhailulaslam.com/
Description:   Developer Machine Test
Version: 9.9.0
Author: Suhailul Aslam KC
Author URI: https://www.suhailulaslam.com/
*/
register_activation_hook( __FILE__, 'my_plugin_create_db' );

function my_plugin_create_db() {

     
}

 
/*
* Registering additional menu in wordpress dashboard
*
*/
add_action('admin_menu', 'reg_fun_theme_general_settings');

function reg_fun_theme_general_settings(){
    /*
    *  Creates menu in wordpress
    *
    */
    add_menu_page('Social Media Icons', 'Social Media Icons', 'manage_options', 'social-media-icons', 'fun_theme_general_settings', 'dashicons-feedback', 66);

}

function fun_theme_general_settings() {
     

    if ($_POST){
        $error_msg;
        $error_msg_social;
        

        $txt_facebook = trim($_POST['txt_facebook']);
        $txt_twitter = trim($_POST['txt_twitter']);
      
        $txt_instagram = trim($_POST['txt_instagram']);
  
       
        /*
        * Update Socail details
        *
        */
        if(!empty($txt_facebook)){
            if (preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$txt_facebook)) {
            update_option('facebook', stripslashes($txt_facebook));
        }else{
            $error_msg_social.="<li> Invalid Facebook Url</li>";
        }
        }else{
            update_option('facebook','');
        }
        if(!empty($txt_twitter)){
            if (preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$txt_twitter)) {
                update_option('twitter', stripslashes($txt_twitter));
            }else{
                $error_msg_social.="<li> Invalid Twitter Url</li>";
            }
        }else{
            update_option('twitter', '');
        }
        
            
            
            
            if(!empty($txt_instagram)){
                if (preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$txt_instagram)) {
                update_option('instagram', stripslashes($txt_instagram));
            }else{
                $error_msg_social.="<li> Invalid Instagram Url</li>";
            }
            }else{
            update_option('instagram', '');
            }
       
    }
 
    $facebook = get_option('facebook');
    $twitter = get_option('twitter');
    $instagram = get_option('instagram');
   
    ?>
    <div class="theme_options_wrapper">
        <form action="" method="post" name="frm_theme_options">
             
             
            <div class="theme_options_contents">
               
                                    <div class="contents tab_contents tab_head_5_content" id="tab_content_5">
                                        <h2>Social Media Accounts Details</h2>
                                        <h4>Use the shortcode [social] to display the social icons</h4>
                                        <?php if(!empty($error_msg_social)){ ?>
                                        <div class="alert alert-danger" role="alert">
                                        <ul>
                                            <?php echo $error_msg_social; ?>
                                        </ul>
                                         </div>
                                    <?php } ?>
                                        <div class="form_input_item">
                                            <div class="col1">
                                                <label>Facebook:</label>
                                                <span>https://facebook.com/xxx</span> </div>
                                                <div class="col2">
                                                    <input type="text" class="text-fields-full" value="<?php if(!empty($_POST['txt_facebook'])){ echo $_POST['txt_facebook'];} else if(!empty($facebook)) { echo $facebook;}?>" name="txt_facebook">
                                                </div>
                                                <div class="col3"></div>
                                            </div>
                                            <div class="form_input_item">
                                                <div class="col1">
                                                    <label>Twitter:</label>
                                                    <span>https://twitter.com/xxx</span> </div>
                                                    <div class="col2">
                                                        <input type="text" class="text-fields-full" name="txt_twitter" value="<?php if(!empty($_POST['txt_twitter'])){echo $_POST['txt_twitter'];} else if(!empty($twitter)) { echo $twitter;}?>">
                                                    </div>
                                                    <div class="col3"></div>
                                                </div>
                                               
                                                     
                                                       
                                                                <div class="form_input_item">
                                                                    <div class="col1">
                                                                        <label>Instagram:</label>
                                                                        <span>https://www.instagram.com/xxx</span> </div>
                                                                        <div class="col2">
                                                                            <input type="text" class="text-fields-full" name="txt_instagram" value="<?php if(!empty($_POST['txt_instagram'])){ echo $_POST['txt_instagram'];} else if(!empty($instagram)) { echo $instagram;}?>">
                                                                        </div>
                                                                        <div class="col3"></div>
                                                                    </div>

                                                                    <div class="clearFixer">&nbsp;</div>
                                                                    <br />
                                                                  
                                                                    <div class="form_footer">
                                                                        <div class="col1">&nbsp;</div>
                                                                        <div class="col2">
                                                                            <input type="submit" value="Save Changes" class="blue-button update_btn" >
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            
                                                                     
                                                                </div>
                                                                
 </form>
 </div>
 <?php }

  
// function that runs when shortcode is called
function wpb_social_shortcode() { 

   $facebook = get_option('facebook');
    $twitter = get_option('twitter');;

    $instagram = get_option('instagram'); ?>

<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 <style type="text/css">
     .footsocials {
    padding: 10px;
    border: 1px solid #b9b9b9;
}
.footsocials a {
    color: black;
    font-size: 26px;
    margin-right: 13px;
}
.footsocials h4 {
    font-weight: 900;
    margin-bottom: 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid;
}


 </style>
<div class="footsocials">

    <h4>Follow Us</h4>
                                     
                                            <a target="_blank" href="<?= $facebook; ?>"><i class="fa fa-facebook" aria-hidden="true"></i></a>

                                             <a target="_blank"  href="<?= $twitter ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                 
                                            <a target="_blank"  href="<?= $instagram ?>"><i class="fa fa-instagram" aria-hidden="true"></i></a>
             
   
       
             </div>
<?php } 
// register shortcode
add_shortcode('social', 'wpb_social_shortcode'); 



  ?>


